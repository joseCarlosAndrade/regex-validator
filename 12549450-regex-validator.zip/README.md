# Regex validator

Atividade para a disciplina: SCC0961 - Desenvolvimento Web e Mobile (2024). A proposta é validar as entradas do usuário na página `index.html` usando REGEX em javascript.

Para testar, basta acessar o link do github pages [neste link.](https://josecarlosandrade.github.io/regex-validator/)

Feito por:

- José Carlos Andrade do Nascimento
